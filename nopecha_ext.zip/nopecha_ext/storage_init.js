
// Auto-generated storage initialization for NopeCHA extension
(function() {
  const nopecha_api_key = 'i4zhbra11oemhvf8';
  chrome.storage.local.set({'nopecha_key': nopecha_api_key}, function() {
    console.log('[NopeCHA Storage] API Key initialized');
  });
})();
